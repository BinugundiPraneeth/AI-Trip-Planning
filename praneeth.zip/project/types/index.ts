export interface TripPlan {
  destination: string;
  duration: number;
  budget: number;
  interests: string[];
  highlights: string[];
  dailyItinerary: DayPlan[];
  tips: string[];
  totalCost: number;
  flightInfo?: FlightInfo;
  generalInfo: GeneralInfo;
}

export interface DayPlan {
  day: number;
  activities: Activity[];
  meals: Meal[];
  accommodation: Accommodation;
  dayCost: number;
}

export interface Activity {
  name: string;
  type: string;
  description: string;
  duration: string;
  cost: number;
  location?: string;
  coordinates?: { lat: number; lng: number };
  bookingUrl?: string;
  rating?: number;
}

export interface Meal {
  type: 'breakfast' | 'lunch' | 'dinner';
  suggestion: string;
  cost: number;
  restaurant?: string;
  location?: string;
  coordinates?: { lat: number; lng: number };
  bookingUrl?: string;
  rating?: number;
}

export interface Accommodation {
  name: string;
  type: string;
  cost: number;
  location?: string;
  coordinates?: { lat: number; lng: number };
  bookingUrl?: string;
  rating?: number;
  amenities?: string[];
}

export interface FlightInfo {
  departure: string;
  arrival: string;
  estimatedCost: number;
  bookingUrl: string;
  duration: string;
}

export interface GeneralInfo {
  bestTimeToVisit: string;
  currency: string;
  language: string;
  timeZone: string;
  weatherTips: string[];
}

export interface TripFormData {
  destination: string;
  duration: number;
  budget: number;
  interests: string[];
  departureCity: string;
  travelDates: {
    start: string;
    end: string;
  };
}