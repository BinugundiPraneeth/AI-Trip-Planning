import React, { useState } from 'react';
import { TripPlan } from '../../types';
import { 
  MapPin, Calendar, DollarSign, Star, Clock, ChevronDown, ChevronUp, 
  Utensils, Hotel, RefreshCw, ExternalLink, Navigation, Plane, 
  Globe, Thermometer, Info, CreditCard
} from 'lucide-react';

interface TripPlanResultProps {
  plan: TripPlan;
  onReset: () => void;
}

const TripPlanResult: React.FC<TripPlanResultProps> = ({ plan, onReset }) => {
  const [expandedDays, setExpandedDays] = useState<number[]>([1]);
  const [activeTab, setActiveTab] = useState<'itinerary' | 'info' | 'flights'>('itinerary');

  const toggleDayExpansion = (day: number) => {
    setExpandedDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day) 
        : [...prev, day]
    );
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getInterestIcon = (type: string) => {
    const icons: { [key: string]: string } = {
      'adventure': '🧗‍♂️',
      'food': '🍽️',
      'cultural': '🏛️',
      'relaxation': '🧘‍♀️',
      'shopping': '🛍️',
      'sightseeing': '📸',
      'local experience': '🌆',
      'travel': '✈️',
      'exploration': '🔍',
      'nightlife': '🌃',
      'nature': '🌿',
      'history': '📚',
      'art': '🎨'
    };
    return icons[type] || '📍';
  };

  const generateGoogleMapsUrl = (location: string, coordinates?: { lat: number; lng: number }) => {
    if (coordinates) {
      return `https://www.google.com/maps/search/?api=1&query=${coordinates.lat},${coordinates.lng}`;
    }
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location + ', ' + plan.destination)}`;
  };

  const generateBookingUrl = (type: 'hotel' | 'restaurant' | 'activity', name: string, location?: string) => {
    const query = encodeURIComponent(`${name} ${location || plan.destination}`);
    switch (type) {
      case 'hotel':
        return `https://www.booking.com/search.html?ss=${query}`;
      case 'restaurant':
        return `https://www.opentable.com/s?query=${query}`;
      case 'activity':
        return `https://www.viator.com/search?query=${query}`;
      default:
        return '#';
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        size={12}
        className={i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}
      />
    ));
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden max-w-6xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white p-6 md:p-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h2 className="text-3xl font-bold mb-2 flex items-center">
              <MapPin className="mr-3" size={32} />
              Your Trip to {plan.destination}
            </h2>
            <div className="flex flex-wrap gap-3 mb-4">
              <span className="inline-flex items-center text-sm bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                <Calendar size={14} className="mr-1" />
                {plan.duration} days
              </span>
              <span className="inline-flex items-center text-sm bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                <DollarSign size={14} className="mr-1" />
                Budget: {formatCurrency(plan.budget)}
              </span>
              {plan.interests.slice(0, 3).map((interest) => (
                <span key={interest} className="inline-flex items-center text-sm bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                  {getInterestIcon(interest)} {interest.charAt(0).toUpperCase() + interest.slice(1)}
                </span>
              ))}
            </div>
          </div>
          <button
            onClick={onReset}
            className="flex items-center text-sm bg-white/20 backdrop-blur-sm hover:bg-white/30 px-4 py-2 rounded-lg transition-all"
          >
            <RefreshCw size={16} className="mr-2" />
            Plan New Trip
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b">
        <nav className="flex">
          {[
            { id: 'itinerary', label: 'Itinerary', icon: Calendar },
            { id: 'flights', label: 'Flights', icon: Plane },
            { id: 'info', label: 'Travel Info', icon: Info }
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <Icon size={16} className="mr-2" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-6 md:p-8">
        {/* Flights Tab */}
        {activeTab === 'flights' && plan.flightInfo && (
          <div className="space-y-6">
            <div className="bg-blue-50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                <Plane className="mr-2 text-blue-500" />
                Flight Information
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Route</span>
                    <span className="font-medium">{plan.flightInfo.departure} → {plan.flightInfo.arrival}</span>
                  </div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Duration</span>
                    <span className="font-medium">{plan.flightInfo.duration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Estimated Cost</span>
                    <span className="font-bold text-green-600">{formatCurrency(plan.flightInfo.estimatedCost)}</span>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <a
                    href={plan.flightInfo.bookingUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <ExternalLink size={16} className="mr-2" />
                    Book Flights
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Travel Info Tab */}
        {activeTab === 'info' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <Globe className="mr-2 text-blue-500" />
                  General Information
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Best Time to Visit</span>
                    <span className="font-medium">{plan.generalInfo.bestTimeToVisit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Currency</span>
                    <span className="font-medium">{plan.generalInfo.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Language</span>
                    <span className="font-medium">{plan.generalInfo.language}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Time Zone</span>
                    <span className="font-medium">{plan.generalInfo.timeZone}</span>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                  <Thermometer className="mr-2 text-yellow-500" />
                  Weather Tips
                </h3>
                <ul className="space-y-2">
                  {plan.generalInfo.weatherTips.map((tip, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-yellow-500 mr-2">•</span>
                      <span className="text-sm">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="bg-green-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Travel Tips</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {plan.tips.map((tip, index) => (
                  <div key={index} className="flex items-start">
                    <span className="text-green-500 mr-2">💡</span>
                    <span className="text-sm">{tip}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Itinerary Tab */}
        {activeTab === 'itinerary' && (
          <div className="space-y-8">
            {/* Trip Highlights */}
            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                <Star className="mr-2 text-yellow-500" />
                Trip Highlights
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {plan.highlights.map((highlight, index) => (
                  <div key={index} className="flex items-start bg-yellow-50 p-4 rounded-lg">
                    <span className="text-yellow-500 mr-3">✨</span>
                    <span className="font-medium">{highlight}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Daily Itinerary */}
            <div>
              <h3 className="text-xl font-semibold text-gray-800 mb-6">Daily Itinerary</h3>
              
              <div className="space-y-4">
                {plan.dailyItinerary.map((day) => (
                  <div key={day.day} className="border-2 border-gray-200 rounded-xl overflow-hidden bg-gray-50">
                    <button
                      onClick={() => toggleDayExpansion(day.day)}
                      className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center">
                        <span className="bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold rounded-full w-10 h-10 flex items-center justify-center mr-4">
                          {day.day}
                        </span>
                        <div>
                          <h4 className="text-lg font-semibold">Day {day.day}</h4>
                          <p className="text-sm text-gray-600">{day.activities.length} activities • {day.meals.length} meals planned</p>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <span className="mr-4 text-green-600 font-bold text-lg">
                          {formatCurrency(day.dayCost)}
                        </span>
                        {expandedDays.includes(day.day) ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
                      </div>
                    </button>
                    
                    {expandedDays.includes(day.day) && (
                      <div className="p-6 border-t bg-white">
                        {/* Activities */}
                        <div className="mb-8">
                          <h5 className="text-lg font-semibold mb-4">Activities</h5>
                          <div className="space-y-4">
                            {day.activities.map((activity, index) => (
                              <div key={index} className="bg-gray-50 p-4 rounded-xl border">
                                <div className="flex justify-between items-start mb-3">
                                  <div className="flex-1">
                                    <h6 className="font-semibold text-lg flex items-center mb-2">
                                      <span className="mr-2 text-xl">{getInterestIcon(activity.type)}</span>
                                      {activity.name}
                                      {activity.rating && (
                                        <div className="flex items-center ml-2">
                                          {renderStars(activity.rating)}
                                          <span className="ml-1 text-sm text-gray-600">({activity.rating})</span>
                                        </div>
                                      )}
                                    </h6>
                                    <p className="text-gray-600 mb-3">{activity.description}</p>
                                    <div className="flex items-center text-sm text-gray-500 mb-3">
                                      <Clock size={14} className="mr-1" />
                                      {activity.duration}
                                      {activity.location && (
                                        <>
                                          <span className="mx-2">•</span>
                                          <MapPin size={14} className="mr-1" />
                                          {activity.location}
                                        </>
                                      )}
                                    </div>
                                  </div>
                                  <div className="text-right ml-4">
                                    <span className="text-green-600 font-bold text-lg">{formatCurrency(activity.cost)}</span>
                                  </div>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                  {activity.location && (
                                    <a
                                      href={generateGoogleMapsUrl(activity.location, activity.coordinates)}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full hover:bg-blue-200 transition-colors"
                                    >
                                      <Navigation size={12} className="mr-1" />
                                      View on Map
                                    </a>
                                  )}
                                  <a
                                    href={activity.bookingUrl || generateBookingUrl('activity', activity.name, activity.location)}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full hover:bg-green-200 transition-colors"
                                  >
                                    <ExternalLink size={12} className="mr-1" />
                                    Book Now
                                  </a>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        {/* Meals */}
                        <div className="mb-8">
                          <h5 className="text-lg font-semibold mb-4">Meals</h5>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {day.meals.map((meal, index) => (
                              <div key={index} className="bg-gray-50 p-4 rounded-xl border">
                                <div className="flex justify-between items-start mb-2">
                                  <div className="flex-1">
                                    <h6 className="font-semibold flex items-center mb-1">
                                      <Utensils size={16} className="mr-2 text-blue-500" />
                                      {meal.type.charAt(0).toUpperCase() + meal.type.slice(1)}
                                    </h6>
                                    <p className="text-sm text-gray-600 mb-2">{meal.suggestion}</p>
                                    {meal.restaurant && (
                                      <p className="text-xs text-gray-500 mb-2">
                                        <strong>Recommended:</strong> {meal.restaurant}
                                        {meal.rating && (
                                          <span className="flex items-center mt-1">
                                            {renderStars(meal.rating)}
                                            <span className="ml-1 text-xs">({meal.rating})</span>
                                          </span>
                                        )}
                                      </p>
                                    )}
                                  </div>
                                  <span className="text-green-600 font-bold">{formatCurrency(meal.cost)}</span>
                                </div>
                                <div className="flex flex-wrap gap-1">
                                  {meal.location && (
                                    <a
                                      href={generateGoogleMapsUrl(meal.location, meal.coordinates)}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full hover:bg-blue-200 transition-colors"
                                    >
                                      <Navigation size={10} className="mr-1" />
                                      Map
                                    </a>
                                  )}
                                  <a
                                    href={meal.bookingUrl || generateBookingUrl('restaurant', meal.restaurant || meal.suggestion, meal.location)}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full hover:bg-green-200 transition-colors"
                                  >
                                    <ExternalLink size={10} className="mr-1" />
                                    Reserve
                                  </a>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        {/* Accommodation */}
                        <div>
                          <h5 className="text-lg font-semibold mb-4">Accommodation</h5>
                          <div className="bg-gray-50 p-4 rounded-xl border">
                            <div className="flex justify-between items-start mb-3">
                              <div className="flex-1">
                                <h6 className="font-semibold text-lg flex items-center mb-2">
                                  <Hotel size={18} className="mr-2 text-blue-500" />
                                  {day.accommodation.name}
                                  {day.accommodation.rating && (
                                    <div className="flex items-center ml-2">
                                      {renderStars(day.accommodation.rating)}
                                      <span className="ml-1 text-sm text-gray-600">({day.accommodation.rating})</span>
                                    </div>
                                  )}
                                </h6>
                                <p className="text-gray-600 mb-2">{day.accommodation.type}</p>
                                {day.accommodation.amenities && (
                                  <div className="flex flex-wrap gap-1 mb-3">
                                    {day.accommodation.amenities.slice(0, 4).map((amenity, i) => (
                                      <span key={i} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                                        {amenity}
                                      </span>
                                    ))}
                                  </div>
                                )}
                                {day.accommodation.location && (
                                  <p className="text-sm text-gray-500 flex items-center">
                                    <MapPin size={12} className="mr-1" />
                                    {day.accommodation.location}
                                  </p>
                                )}
                              </div>
                              <div className="text-right ml-4">
                                <span className="text-green-600 font-bold text-lg">{formatCurrency(day.accommodation.cost)}</span>
                                <p className="text-xs text-gray-500">per night</p>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {day.accommodation.location && (
                                <a
                                  href={generateGoogleMapsUrl(day.accommodation.location, day.accommodation.coordinates)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center text-xs bg-blue-100 text-blue-700 px-3 py-1 rounded-full hover:bg-blue-200 transition-colors"
                                >
                                  <Navigation size={12} className="mr-1" />
                                  View Location
                                </a>
                              )}
                              <a
                                href={day.accommodation.bookingUrl || generateBookingUrl('hotel', day.accommodation.name, day.accommodation.location)}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full hover:bg-green-200 transition-colors"
                              >
                                <ExternalLink size={12} className="mr-1" />
                                Book Hotel
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Total Cost Overview */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-xl border-2 border-blue-200">
              <div className="flex flex-col md:flex-row justify-between items-center">
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center">
                    <CreditCard className="mr-2 text-blue-500" />
                    Total Trip Cost
                  </h3>
                  <p className="text-sm text-gray-600">Including flights, accommodation, meals, and activities</p>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-blue-700 mb-1">
                    {formatCurrency(plan.totalCost)}
                  </div>
                  <div className="text-sm text-gray-600">
                    {plan.totalCost <= plan.budget ? (
                      <span className="text-green-600 font-medium">
                        ✅ Within budget! Saving {formatCurrency(plan.budget - plan.totalCost)}
                      </span>
                    ) : (
                      <span className="text-red-600 font-medium">
                        ⚠️ Over budget by {formatCurrency(plan.totalCost - plan.budget)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TripPlanResult;