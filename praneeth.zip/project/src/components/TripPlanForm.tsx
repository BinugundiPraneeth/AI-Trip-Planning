import React, { useState } from 'react';
import { MapPin, Calendar, DollarSign, Users, Plane, Heart } from 'lucide-react';
import { TripFormData } from '../../types';

interface TripPlanFormProps {
  onSubmit: (data: TripFormData) => void;
  isLoading: boolean;
}

const TripPlanForm: React.FC<TripPlanFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<TripFormData>({
    destination: '',
    duration: 7,
    budget: 2000,
    interests: [],
    departureCity: '',
    travelDates: {
      start: '',
      end: ''
    }
  });

  const interestOptions = [
    { id: 'adventure', label: 'Adventure', icon: '🧗‍♂️' },
    { id: 'food', label: 'Food & Dining', icon: '🍽️' },
    { id: 'cultural', label: 'Cultural Sites', icon: '🏛️' },
    { id: 'relaxation', label: 'Relaxation', icon: '🧘‍♀️' },
    { id: 'shopping', label: 'Shopping', icon: '🛍️' },
    { id: 'sightseeing', label: 'Sightseeing', icon: '📸' },
    { id: 'nightlife', label: 'Nightlife', icon: '🌃' },
    { id: 'nature', label: 'Nature', icon: '🌿' },
    { id: 'history', label: 'History', icon: '📚' },
    { id: 'art', label: 'Art & Museums', icon: '🎨' }
  ];

  const handleInterestToggle = (interest: string) => {
    setFormData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.destination && formData.departureCity && formData.interests.length > 0) {
      onSubmit(formData);
    }
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mb-4">
          <Plane className="text-white" size={24} />
        </div>
        <h2 className="text-3xl font-bold text-gray-800 mb-2">Plan Your Perfect Trip</h2>
        <p className="text-gray-600">Tell us your preferences and we'll create a personalized itinerary</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Destination and Departure */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <MapPin size={16} className="inline mr-1" />
              Where do you want to go?
            </label>
            <input
              type="text"
              value={formData.destination}
              onChange={(e) => setFormData(prev => ({ ...prev, destination: e.target.value }))}
              placeholder="e.g., Paris, Tokyo, New York"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Plane size={16} className="inline mr-1" />
              Departing from?
            </label>
            <input
              type="text"
              value={formData.departureCity}
              onChange={(e) => setFormData(prev => ({ ...prev, departureCity: e.target.value }))}
              placeholder="e.g., Los Angeles, London"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
        </div>

        {/* Travel Dates */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar size={16} className="inline mr-1" />
              Start Date
            </label>
            <input
              type="date"
              value={formData.travelDates.start}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                travelDates: { ...prev.travelDates, start: e.target.value }
              }))}
              min={today}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar size={16} className="inline mr-1" />
              End Date
            </label>
            <input
              type="date"
              value={formData.travelDates.end}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                travelDates: { ...prev.travelDates, end: e.target.value }
              }))}
              min={formData.travelDates.start || today}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              required
            />
          </div>
        </div>

        {/* Duration and Budget */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Users size={16} className="inline mr-1" />
              Trip Duration
            </label>
            <select
              value={formData.duration}
              onChange={(e) => setFormData(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            >
              {[3, 4, 5, 6, 7, 8, 9, 10, 14, 21].map(days => (
                <option key={days} value={days}>
                  {days} {days === 1 ? 'day' : 'days'}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <DollarSign size={16} className="inline mr-1" />
              Budget (USD)
            </label>
            <select
              value={formData.budget}
              onChange={(e) => setFormData(prev => ({ ...prev, budget: parseInt(e.target.value) }))}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            >
              <option value={1000}>$1,000 - Budget</option>
              <option value={2000}>$2,000 - Moderate</option>
              <option value={3500}>$3,500 - Comfortable</option>
              <option value={5000}>$5,000 - Luxury</option>
              <option value={7500}>$7,500+ - Premium</option>
            </select>
          </div>
        </div>

        {/* Interests */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            <Heart size={16} className="inline mr-1" />
            What interests you? (Select at least one)
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {interestOptions.map(option => (
              <button
                key={option.id}
                type="button"
                onClick={() => handleInterestToggle(option.id)}
                className={`p-3 rounded-lg border-2 transition-all text-sm font-medium ${
                  formData.interests.includes(option.id)
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300 text-gray-700'
                }`}
              >
                <span className="block text-lg mb-1">{option.icon}</span>
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading || !formData.destination || !formData.departureCity || formData.interests.length === 0}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 rounded-lg font-semibold text-lg hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-[1.02] active:scale-[0.98]"
        >
          {isLoading ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
              Creating Your Perfect Trip...
            </div>
          ) : (
            'Create My Trip Plan'
          )}
        </button>
      </form>
    </div>
  );
};

export default TripPlanForm;