import React, { useState } from 'react';
import { TripPlan } from '../types';
import { MapPin, Calendar, DollarSign, Star, Clock, ChevronDown, ChevronUp, Utensils, Hotel, RefreshCw } from 'lucide-react';

interface TripPlanResultProps {
  plan: TripPlan;
  onReset: () => void;
}

const TripPlanResult: React.FC<TripPlanResultProps> = ({ plan, onReset }) => {
  const [expandedDays, setExpandedDays] = useState<number[]>([1]); // First day expanded by default

  const toggleDayExpansion = (day: number) => {
    setExpandedDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day) 
        : [...prev, day]
    );
  };

  // Format number as currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getInterestIcon = (type: string) => {
    switch (type) {
      case 'adventure': return '🧗‍♂️';
      case 'food': return '🍽️';
      case 'cultural': return '🏛️';
      case 'relaxation': return '🧘‍♀️';
      case 'shopping': return '🛍️';
      case 'sightseeing': return '📸';
      case 'local experience': return '🌆';
      case 'travel': return '✈️';
      case 'exploration': return '🔍';
      default: return '📍';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 md:p-8 max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b pb-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2 flex items-center">
            <MapPin className="mr-2 text-blue-500" />
            Your Trip to {plan.destination}
          </h2>
          <div className="flex flex-wrap gap-3 mb-4">
            <span className="inline-flex items-center text-sm bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
              <Calendar size={14} className="mr-1" />
              {plan.duration} days
            </span>
            <span className="inline-flex items-center text-sm bg-green-50 text-green-700 px-3 py-1 rounded-full">
              <DollarSign size={14} className="mr-1" />
              Budget: {formatCurrency(plan.budget)}
            </span>
            {plan.interests.map((interest) => (
              <span key={interest} className="inline-flex items-center text-sm bg-purple-50 text-purple-700 px-3 py-1 rounded-full">
                {getInterestIcon(interest)} {interest.charAt(0).toUpperCase() + interest.slice(1)}
              </span>
            ))}
          </div>
        </div>
        <button
          onClick={onReset}
          className="flex items-center text-sm text-gray-600 hover:text-blue-600 transition-colors"
        >
          <RefreshCw size={14} className="mr-1" />
          Plan a new trip
        </button>
      </div>

      {/* Trip Highlights */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center">
          <Star className="mr-2 text-yellow-500" />
          Trip Highlights
        </h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {plan.highlights.map((highlight, index) => (
            <li key={index} className="flex items-start">
              <span className="text-blue-500 mr-2">•</span>
              <span>{highlight}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Daily Itinerary */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Daily Itinerary</h3>
        
        <div className="space-y-4">
          {plan.dailyItinerary.map((day) => (
            <div key={day.day} className="border rounded-lg overflow-hidden bg-gray-50">
              <button
                onClick={() => toggleDayExpansion(day.day)}
                className="w-full flex items-center justify-between p-4 text-left focus:outline-none"
              >
                <div className="flex items-center">
                  <span className="bg-blue-500 text-white font-bold rounded-full w-7 h-7 flex items-center justify-center mr-3">
                    {day.day}
                  </span>
                  <div>
                    <h4 className="font-medium">Day {day.day}</h4>
                    <p className="text-sm text-gray-600">{day.activities.length} activities planned</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className="mr-3 text-green-600 font-medium">
                    {formatCurrency(day.dayCost)}
                  </span>
                  {expandedDays.includes(day.day) ? <ChevronUp /> : <ChevronDown />}
                </div>
              </button>
              
              {expandedDays.includes(day.day) && (
                <div className="p-4 border-t">
                  {/* Activities */}
                  <div className="mb-4">
                    <h5 className="font-medium mb-2">Activities</h5>
                    <div className="space-y-3">
                      {day.activities.map((activity, index) => (
                        <div key={index} className="bg-white p-3 rounded-lg border">
                          <div className="flex justify-between mb-1">
                            <h6 className="font-medium flex items-center">
                              <span className="mr-2">{getInterestIcon(activity.type)}</span>
                              {activity.name}
                            </h6>
                            <span className="text-green-600 text-sm">{formatCurrency(activity.cost)}</span>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{activity.description}</p>
                          <div className="flex items-center text-xs text-gray-500">
                            <Clock size={12} className="mr-1" />
                            {activity.duration}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Meals */}
                  <div className="mb-4">
                    <h5 className="font-medium mb-2">Meals</h5>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {day.meals.map((meal, index) => (
                        <div key={index} className="bg-white p-3 rounded-lg border">
                          <div className="flex justify-between items-start">
                            <div>
                              <h6 className="font-medium flex items-center text-sm">
                                <Utensils size={14} className="mr-1 text-blue-500" />
                                {meal.type.charAt(0).toUpperCase() + meal.type.slice(1)}
                              </h6>
                              <p className="text-sm text-gray-600">{meal.suggestion}</p>
                            </div>
                            <span className="text-green-600 text-xs">{formatCurrency(meal.cost)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Accommodation */}
                  <div>
                    <h5 className="font-medium mb-2">Accommodation</h5>
                    <div className="bg-white p-3 rounded-lg border">
                      <div className="flex justify-between items-start">
                        <div>
                          <h6 className="font-medium flex items-center">
                            <Hotel size={14} className="mr-1 text-blue-500" />
                            {day.accommodation.name}
                          </h6>
                          <p className="text-sm text-gray-600">{day.accommodation.type}</p>
                        </div>
                        <span className="text-green-600 text-sm">{formatCurrency(day.accommodation.cost)}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Travel Tips */}
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Travel Tips</h3>
        <ul className="space-y-2">
          {plan.tips.map((tip, index) => (
            <li key={index} className="flex items-start bg-yellow-50 p-3 rounded-lg">
              <span className="text-yellow-500 mr-2">💡</span>
              <span className="text-sm">{tip}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Total Cost Overview */}
      <div className="mt-6 bg-blue-50 p-4 rounded-lg">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-800 mb-2 md:mb-0">
            Total Trip Cost
          </h3>
          <div className="text-2xl font-bold text-blue-700">
            {formatCurrency(plan.totalCost)}
          </div>
        </div>
        <div className="text-sm text-gray-600 mt-1">
          {plan.totalCost <= plan.budget ? (
            <span className="text-green-600">
              Your trip is within budget! You're saving {formatCurrency(plan.budget - plan.totalCost)}.
            </span>
          ) : (
            <span className="text-red-600">
              Your trip is over budget by {formatCurrency(plan.totalCost - plan.budget)}. Consider adjusting some activities.
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default TripPlanResult;