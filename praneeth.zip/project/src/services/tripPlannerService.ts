import { TripFormData, TripPlan } from '../../types';

// Mock data generator for demonstration
export const generateTripPlan = async (formData: TripFormData): Promise<TripPlan> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 3000));

  const { destination, duration, budget, interests, departureCity } = formData;

  // Sample data - in a real app, this would come from an AI service
  const samplePlans: { [key: string]: Partial<TripPlan> } = {
    'paris': {
      highlights: [
        'Visit the iconic Eiffel Tower and enjoy panoramic city views',
        'Explore world-class art at the Louvre Museum',
        'Stroll through charming Montmartre district',
        'Experience authentic French cuisine in local bistros',
        'Take a romantic Seine River cruise at sunset'
      ],
      generalInfo: {
        bestTimeToVisit: 'April-June, September-October',
        currency: 'Euro (EUR)',
        language: 'French',
        timeZone: 'Central European Time (CET)',
        weatherTips: [
          'Pack layers as weather can be unpredictable',
          'Bring comfortable walking shoes',
          'Light rain jacket recommended',
          'Summer can be warm, winter quite cold'
        ]
      },
      tips: [
        'Learn basic French phrases - locals appreciate the effort',
        'Book restaurant reservations in advance',
        'Metro day passes offer great value for transportation',
        'Many museums are free on first Sunday mornings',
        'Tipping 10% is standard in restaurants',
        'Avoid tourist traps near major landmarks for dining'
      ]
    },
    'tokyo': {
      highlights: [
        'Experience the bustling energy of Shibuya Crossing',
        'Discover traditional culture in Asakusa district',
        'Enjoy world-renowned sushi at Tsukiji Market',
        'Explore modern architecture in Shinjuku',
        'Relax in beautiful traditional gardens'
      ],
      generalInfo: {
        bestTimeToVisit: 'March-May, September-November',
        currency: 'Japanese Yen (JPY)',
        language: 'Japanese',
        timeZone: 'Japan Standard Time (JST)',
        weatherTips: [
          'Spring brings beautiful cherry blossoms',
          'Summer is hot and humid with frequent rain',
          'Autumn offers pleasant weather and fall colors',
          'Winter is mild but can be chilly'
        ]
      },
      tips: [
        'Get a JR Pass for unlimited train travel',
        'Cash is still king - many places don\'t accept cards',
        'Bowing is a sign of respect',
        'Remove shoes when entering homes and some restaurants',
        'Slurping noodles is perfectly acceptable',
        'Download Google Translate with camera feature'
      ]
    },
    'new york': {
      highlights: [
        'Take in breathtaking views from the Empire State Building',
        'Explore world-class museums like MoMA and Met',
        'Catch a Broadway show in the Theater District',
        'Stroll through iconic Central Park',
        'Experience diverse neighborhoods like SoHo and Greenwich Village'
      ],
      generalInfo: {
        bestTimeToVisit: 'April-June, September-November',
        currency: 'US Dollar (USD)',
        language: 'English',
        timeZone: 'Eastern Time (ET)',
        weatherTips: [
          'Dress in layers - weather can change quickly',
          'Summer can be very hot and humid',
          'Winter requires warm clothing and boots',
          'Spring and fall offer the most pleasant weather'
        ]
      },
      tips: [
        'Use the subway - it\'s faster than taxis in traffic',
        'Tipping 18-20% is expected in restaurants',
        'Book Broadway shows and popular restaurants in advance',
        'Walk fast and stay aware of your surroundings',
        'Many museums have suggested donation policies',
        'Food trucks offer great, affordable meals'
      ]
    }
  };

  const destinationKey = destination.toLowerCase();
  const planTemplate = samplePlans[destinationKey] || samplePlans['paris'];

  // Generate daily itinerary
  const dailyItinerary = Array.from({ length: duration }, (_, index) => {
    const day = index + 1;
    const dailyBudget = budget / duration;
    
    return {
      day,
      activities: generateActivities(destination, interests, dailyBudget * 0.4),
      meals: generateMeals(destination, dailyBudget * 0.3),
      accommodation: generateAccommodation(destination, dailyBudget * 0.3),
      dayCost: dailyBudget
    };
  });

  const flightCost = calculateFlightCost(departureCity, destination);
  const totalCost = dailyItinerary.reduce((sum, day) => sum + day.dayCost, 0) + flightCost;

  return {
    destination,
    duration,
    budget,
    interests,
    highlights: planTemplate.highlights || [],
    dailyItinerary,
    tips: planTemplate.tips || [],
    totalCost,
    flightInfo: {
      departure: departureCity,
      arrival: destination,
      estimatedCost: flightCost,
      bookingUrl: `https://www.kayak.com/flights/${departureCity}-${destination}`,
      duration: calculateFlightDuration(departureCity, destination)
    },
    generalInfo: planTemplate.generalInfo || {
      bestTimeToVisit: 'Year-round',
      currency: 'Local Currency',
      language: 'Local Language',
      timeZone: 'Local Time',
      weatherTips: ['Check weather before traveling']
    }
  };
};

const generateActivities = (destination: string, interests: string[], budget: number) => {
  const activityTemplates = {
    'cultural': [
      { name: 'Historic Museum Visit', type: 'cultural', description: 'Explore the rich history and culture', duration: '2-3 hours', cost: 25, rating: 4.5 },
      { name: 'Art Gallery Tour', type: 'cultural', description: 'Discover local and international art', duration: '2 hours', cost: 20, rating: 4.3 },
      { name: 'Architecture Walking Tour', type: 'cultural', description: 'Guided tour of architectural highlights', duration: '3 hours', cost: 35, rating: 4.6 }
    ],
    'food': [
      { name: 'Local Food Tour', type: 'food', description: 'Taste authentic local specialties', duration: '3 hours', cost: 65, rating: 4.8 },
      { name: 'Cooking Class', type: 'food', description: 'Learn to cook traditional dishes', duration: '4 hours', cost: 85, rating: 4.7 },
      { name: 'Market Visit', type: 'food', description: 'Explore local markets and taste fresh produce', duration: '2 hours', cost: 30, rating: 4.4 }
    ],
    'adventure': [
      { name: 'City Bike Tour', type: 'adventure', description: 'Explore the city on two wheels', duration: '4 hours', cost: 45, rating: 4.5 },
      { name: 'Hiking Excursion', type: 'adventure', description: 'Scenic hike with beautiful views', duration: '5 hours', cost: 55, rating: 4.6 },
      { name: 'Water Sports Activity', type: 'adventure', description: 'Exciting water-based adventure', duration: '3 hours', cost: 75, rating: 4.4 }
    ],
    'sightseeing': [
      { name: 'City Landmarks Tour', type: 'sightseeing', description: 'Visit iconic landmarks and attractions', duration: '4 hours', cost: 40, rating: 4.5 },
      { name: 'Observation Deck Visit', type: 'sightseeing', description: 'Panoramic city views from above', duration: '1.5 hours', cost: 30, rating: 4.7 },
      { name: 'Historic District Walk', type: 'sightseeing', description: 'Self-guided walk through historic areas', duration: '2 hours', cost: 15, rating: 4.3 }
    ]
  };

  const activities = [];
  const availableTypes = interests.filter(interest => activityTemplates[interest as keyof typeof activityTemplates]);
  
  for (let i = 0; i < 2; i++) {
    const randomType = availableTypes[Math.floor(Math.random() * availableTypes.length)] || 'sightseeing';
    const templates = activityTemplates[randomType as keyof typeof activityTemplates] || activityTemplates.sightseeing;
    const template = templates[Math.floor(Math.random() * templates.length)];
    
    activities.push({
      ...template,
      location: `${template.name} Location, ${destination}`,
      coordinates: { lat: 40.7128 + Math.random() * 0.1, lng: -74.0060 + Math.random() * 0.1 }
    });
  }

  return activities;
};

const generateMeals = (destination: string, budget: number) => {
  const mealTemplates = {
    breakfast: [
      { suggestion: 'Local café with fresh pastries and coffee', cost: 15, restaurant: 'Café Central' },
      { suggestion: 'Traditional breakfast at hotel restaurant', cost: 25, restaurant: 'Hotel Dining Room' },
      { suggestion: 'Street food breakfast experience', cost: 10, restaurant: 'Local Street Vendor' }
    ],
    lunch: [
      { suggestion: 'Authentic local cuisine at family restaurant', cost: 35, restaurant: 'Family Bistro' },
      { suggestion: 'Quick lunch at popular local spot', cost: 20, restaurant: 'Local Favorite' },
      { suggestion: 'Fine dining lunch experience', cost: 55, restaurant: 'Gourmet Restaurant' }
    ],
    dinner: [
      { suggestion: 'Upscale restaurant with local specialties', cost: 75, restaurant: 'Fine Dining Establishment' },
      { suggestion: 'Cozy neighborhood restaurant', cost: 45, restaurant: 'Neighborhood Gem' },
      { suggestion: 'Casual dining with great atmosphere', cost: 35, restaurant: 'Casual Eatery' }
    ]
  };

  return (['breakfast', 'lunch', 'dinner'] as const).map(type => {
    const templates = mealTemplates[type];
    const template = templates[Math.floor(Math.random() * templates.length)];
    
    return {
      type,
      ...template,
      location: `${template.restaurant}, ${destination}`,
      coordinates: { lat: 40.7128 + Math.random() * 0.1, lng: -74.0060 + Math.random() * 0.1 },
      rating: 4.0 + Math.random() * 1.0
    };
  });
};

const generateAccommodation = (destination: string, budget: number) => {
  const accommodationTypes = [
    {
      name: 'Boutique Hotel Central',
      type: 'Boutique Hotel',
      cost: budget * 0.8,
      rating: 4.5,
      amenities: ['Free WiFi', 'Breakfast Included', 'Gym', 'Concierge']
    },
    {
      name: 'Luxury Resort & Spa',
      type: 'Luxury Resort',
      cost: budget * 1.2,
      rating: 4.8,
      amenities: ['Spa', 'Pool', 'Fine Dining', 'Room Service']
    },
    {
      name: 'Modern City Hotel',
      type: 'Business Hotel',
      cost: budget * 0.9,
      rating: 4.3,
      amenities: ['Business Center', 'Free WiFi', 'Fitness Center', 'Restaurant']
    }
  ];

  const accommodation = accommodationTypes[Math.floor(Math.random() * accommodationTypes.length)];
  
  return {
    ...accommodation,
    location: `City Center, ${destination}`,
    coordinates: { lat: 40.7128 + Math.random() * 0.05, lng: -74.0060 + Math.random() * 0.05 }
  };
};

const calculateFlightCost = (departure: string, destination: string): number => {
  // Simple flight cost estimation based on distance/popularity
  const baseCosts: { [key: string]: number } = {
    'paris': 600,
    'tokyo': 1200,
    'new york': 400,
    'london': 500,
    'rome': 550,
    'barcelona': 450
  };
  
  return baseCosts[destination.toLowerCase()] || 700;
};

const calculateFlightDuration = (departure: string, destination: string): string => {
  const durations: { [key: string]: string } = {
    'paris': '8h 30m',
    'tokyo': '14h 15m',
    'new york': '5h 45m',
    'london': '7h 20m',
    'rome': '9h 10m',
    'barcelona': '7h 45m'
  };
  
  return durations[destination.toLowerCase()] || '8h 00m';
};